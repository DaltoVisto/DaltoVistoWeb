window.onscroll = function() {
  var y = window.scrollY;
  console.log(y);
};